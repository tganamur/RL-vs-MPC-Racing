Rendering Engine
========================================

This is the rendering engine using pyglet to visualize the running environment.

.. doxygenfile:: rendering.py
    :project: f1tenth_gym